# densityClust 0.3.3

* Upkeep
* Move from Rcpp to cpp11

# densityClust 0.3.2

* Fix more if clauses that could lead to a logical vector instead of a scalar

# densityClust 0.3.1

* Added a `NEWS.md` file to track changes to the package.
* Fix an if clause that could lead to a logical vector instead of a scalar
