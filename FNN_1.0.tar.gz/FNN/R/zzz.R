#Not needed when namespace is implemented.
#
#.First.lib <- function(lib, pkg) {
#       library.dynam("FNN", pkg, lib)
#     }
